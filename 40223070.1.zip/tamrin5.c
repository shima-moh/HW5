#include<stdio.h>
int main()
{
    int n;
    printf("enter a positive integer\n");
    scanf("%d",&n);
    char a[n];
    printf("enter a phrase\n");
    scanf("%s",a);
    for (int i=0;i<n;i++)
    {
        if(a[i]==a[i+1])
        {
            for(int m=i;m<n;m++)
            {
                a[m]=a[m+2];
                if(m==n-2)
                break;
            }
            printf("%s\n",a);
        }
    }

}